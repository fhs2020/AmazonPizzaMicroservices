﻿namespace StarterProject.Context.Base
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
